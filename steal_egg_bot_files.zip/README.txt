StealEggTrackerBot — starter files

Files:
- bot.py: Telegram bot that asks for and stores each Telegram user's Roblox username.
- requirements.txt: Python dependency.

Important:
1. Create a bot with @BotFather.
2. Keep the bot token secret. Do not paste it into public chats or source code.
3. On your hosting provider, set environment variable BOT_TOKEN to your token.
4. Set the start command to: python bot.py
5. Keep users.db on persistent storage so registrations survive redeploys.
6. This starter does NOT detect egg theft or activity across Roblox servers. That requires a permitted game event/data source.
