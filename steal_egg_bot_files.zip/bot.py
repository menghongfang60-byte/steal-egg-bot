import os
import re
import sqlite3
import logging
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

BOT_TOKEN = os.getenv("BOT_TOKEN")
DB_PATH = os.getenv("DB_PATH", "users.db")
TZ = ZoneInfo("Asia/Phnom_Penh")

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

MENU = ReplyKeyboardMarkup(
    [
        ["👤 My Username", "✏️ Change Username"],
        ["🥚 Egg Info", "ℹ️ Help"],
    ],
    resize_keyboard=True,
)

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                telegram_id INTEGER PRIMARY KEY,
                telegram_name TEXT NOT NULL DEFAULT '',
                roblox_username TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        conn.commit()

def get_user(telegram_id):
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        return conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?",
            (telegram_id,),
        ).fetchone()

def save_user(telegram_id, telegram_name, username):
    now = datetime.now(TZ).isoformat(timespec="seconds")
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            INSERT INTO users (
                telegram_id, telegram_name, roblox_username,
                created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                telegram_name = excluded.telegram_name,
                roblox_username = excluded.roblox_username,
                updated_at = excluded.updated_at
        """, (telegram_id, telegram_name or "", username, now, now))
        conn.commit()

def valid_username(username):
    # Basic format check only; it does not confirm the Roblox account exists.
    return bool(re.fullmatch(r"[A-Za-z0-9_]{3,20}", username))

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not update.message:
        return

    saved = get_user(user.id)
    if saved:
        context.user_data["awaiting_username"] = False
        await update.message.reply_text(
            f"👋 ស្វាគមន៍ត្រឡប់មកវិញ!\n\n"
            f"👤 Roblox Username: {saved['roblox_username']}\n\n"
            "Bot បានចងចាំ Username របស់អ្នកហើយ។",
            reply_markup=MENU,
        )
    else:
        context.user_data["awaiting_username"] = True
        await update.message.reply_text(
            "🥚 សូមស្វាគមន៍មកកាន់ StealEggTrackerBot!\n\n"
            "សូមបញ្ចូល Roblox Username របស់អ្នក៖\n"
            "ឧទាហរណ៍៖ houjhj_7\n\n"
            "⚠️ បញ្ចូលតែ Username ប៉ុណ្ណោះ។ កុំផ្ញើ Password។"
        )

async def my_username(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not update.message:
        return
    saved = get_user(user.id)
    if saved:
        await update.message.reply_text(
            f"👤 Roblox Username: {saved['roblox_username']}",
            reply_markup=MENU,
        )
    else:
        context.user_data["awaiting_username"] = True
        await update.message.reply_text("សូមបញ្ចូល Roblox Username របស់អ្នក។")

async def change_username(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message:
        return
    context.user_data["awaiting_username"] = True
    await update.message.reply_text("✏️ សូមបញ្ចូល Roblox Username ថ្មីរបស់អ្នក៖")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message:
        return
    await update.message.reply_text(
        "📖 របៀបប្រើ Bot\n\n"
        "/start - ចាប់ផ្ដើម Bot\n"
        "/myusername - មើល Username\n"
        "/setusername - ប្ដូរ Username\n"
        "/help - ជំនួយ\n\n"
        "Bot នេះរក្សាទុក Username ប៉ុណ្ណោះ។ "
        "ការតាមដានសកម្មភាពពងក្នុង Roblox ត្រូវការប្រភព Event ពីហ្គេមបន្ថែម។",
        reply_markup=MENU,
    )

async def receive_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    message = update.message
    if not user or not message or not message.text:
        return

    text = message.text.strip()

    if text == "👤 My Username":
        await my_username(update, context)
        return
    if text == "✏️ Change Username":
        await change_username(update, context)
        return
    if text == "🥚 Egg Info":
        await message.reply_text(
            "🥚 Egg Tracker\n\n"
            "ប្រព័ន្ធចុះឈ្មោះដំណើរការ។ ការតាមដានសកម្មភាពពីគ្រប់ Server "
            "ត្រូវការប្រភព Event ពីហ្គេម ឬប្រព័ន្ធដែលអនុញ្ញាតជាមុន។",
            reply_markup=MENU,
        )
        return
    if text == "ℹ️ Help":
        await help_command(update, context)
        return

    if not context.user_data.get("awaiting_username"):
        await message.reply_text("សូមប្រើប៊ូតុងខាងក្រោម ឬវាយ /help។", reply_markup=MENU)
        return

    if not valid_username(text):
        await message.reply_text(
            "❌ ទម្រង់ Username មិនត្រឹមត្រូវទេ។ "
            "ប្រើអក្សរ អក្សរធំ លេខ ឬ _ ចន្លោះពី 3 ដល់ 20 តួ។"
        )
        return

    save_user(user.id, user.full_name, text)
    context.user_data["awaiting_username"] = False
    await message.reply_text(
        f"✅ ចុះឈ្មោះជោគជ័យ!\n\n👤 Roblox Username: {text}\n\n"
        "Bot នឹងចងចាំ Username នេះពេលអ្នកត្រឡប់មកប្រើម្ដងទៀត។",
        reply_markup=MENU,
    )

async def post_init(application: Application):
    await application.bot.set_my_commands([
        ("start", "ចាប់ផ្ដើម Bot"),
        ("myusername", "មើល Roblox Username"),
        ("setusername", "ប្ដូរ Roblox Username"),
        ("help", "ជំនួយ"),
    ])

def main():
    if not BOT_TOKEN:
        raise RuntimeError("សូមកំណត់ Environment Variable BOT_TOKEN ជាមុនសិន។")
    init_db()
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("myusername", my_username))
    app.add_handler(CommandHandler("setusername", change_username))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, receive_text))
    logger.info("StealEggTrackerBot is starting...")
    app.run_polling(drop_pending_updates=False)

if __name__ == "__main__":
    main()
